# Content Automation System

AI-powered content automation system for blogs and social media.

## Features

- 🤖 AI-powered blog content generation
- 🎨 Automated image prompt creation
- 📱 Social media post generation
- 👀 Preview and approval system
- 🔄 Multi-site support
- 📊 Analytics integration

## Quick Start

1. Read `GETTING_STARTED.md` for complete setup instructions
2. Install dependencies: `npm install`
3. Copy `.env.example` to `.env` and configure
4. Run setup: `npm run setup`
5. Start development: `npm run dev`

## Documentation

- [Getting Started](GETTING_STARTED.md)
- [Setup Guide](docs/setup.md)
- [Usage Guide](docs/usage.md)
- [API Documentation](docs/api.md)
- [Integration Guide](docs/integration.md)

## Reference Files

All reference files from the original project are in the `reference/` directory.
