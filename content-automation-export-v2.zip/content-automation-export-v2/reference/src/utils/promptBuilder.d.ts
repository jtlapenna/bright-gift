export function buildPrompt(data: {
  recipient: string;
  interests: string;
  budget: string;
  styles?: string[];
}): string; 