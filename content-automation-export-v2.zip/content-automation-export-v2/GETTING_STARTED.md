# Getting Started Guide

## 🚀 Complete Setup Instructions

### Step 1: Extract and Setup
```bash
# Extract the export package
unzip content-automation-export-v2.zip
cd content-automation-export-v2

# Install dependencies
npm install

# Copy environment file
cp .env.example .env
```

### Step 2: Configure Environment
Edit `.env` file with your API keys:
```bash
# OpenAI Configuration
OPENAI_API_KEY=your_openai_api_key
OPENAI_MODEL=gpt-4-turbo-preview

# Site Configuration
SITE_NAME=your_site_name
SITE_DOMAIN=your_domain.com

# Social Media APIs (optional)
TWITTER_API_KEY=your_twitter_api_key
TWITTER_API_SECRET=your_twitter_api_secret
INSTAGRAM_ACCESS_TOKEN=your_instagram_token
PINTEREST_ACCESS_TOKEN=your_pinterest_token
FACEBOOK_ACCESS_TOKEN=your_facebook_token
BLUESKY_IDENTIFIER=your_bluesky_identifier
BLUESKY_PASSWORD=your_bluesky_password
```

### Step 3: Configure Your Site
Edit `config/sites/my-site.json`:
```json
{
  "name": "your-site-name",
  "domain": "your-domain.com",
  "contentDir": "src/content/blog",
  "imagesDir": "public/images/blog",
  "socialPostsDir": "_workflow-documents/social-posts",
  "styleGuide": "reference/_workflow-documents/planning/04.2_blog_style_guide.md",
  "seoGuide": "reference/_workflow-documents/planning/04.3_SEO_Guide.md",
  "affiliatePrograms": {
    "amazon": {
      "enabled": true,
      "tag": "your-amazon-tag"
    },
    "bookshop": {
      "enabled": true,
      "tag": "your-bookshop-tag"
    },
    "afrofiliate": {
      "enabled": true,
      "brands": []
    }
  }
}
```

### Step 4: Run Setup
```bash
# Run the setup script
node setup.js

# Start development
npm run dev
```

### Step 5: Test Integration
```bash
# Test with your existing site
npm run test:integration

# Generate a sample blog post
npm start generate blog
```

## 📚 Key Reference Files

### For AI Content Generation:
1. `reference/_workflow-documents/blogbot-instructions.md` - How to write blog posts
2. `reference/_workflow-documents/planning/04.4_image_prompt_instructions.md` - How to generate images
3. `reference/src/utils/promptBuilder.js` - AI prompt logic
4. `reference/src/pages/api/generate.ts` - Main generation API

### For Affiliate Integration:
1. `reference/_workflow-documents/planning/afrofiliate-blog-linking-guide.md` - Afrofiliate setup
2. `reference/_workflow-documents/planning/bookshop-blog-linking-guide.md` - Bookshop.org setup
3. `reference/_workflow-documents/planning/afrofiliate-integration-strategy.md` - Complete strategy

### For Content Strategy:
1. `reference/_workflow-documents/planning/04.2_blog_style_guide.md` - Content guidelines
2. `reference/_workflow-documents/planning/04.3_SEO_Guide.md` - SEO guidelines
3. `reference/_workflow-documents/planning/non-gift-guide-content-ideas.md` - Content ideas

### For Technical Implementation:
1. `reference/astro.config.mjs` - Astro configuration
2. `reference/src/pages/index.astro` - Main frontend
3. `reference/src/pages/blog/[...slug].astro` - Blog template
4. `reference/package.json` - Dependencies and scripts

## 🔄 Next Steps

1. **Review Reference Files** - Study the existing implementation
2. **Configure Your Site** - Set up your specific configuration
3. **Test with Real Content** - Generate content for your site
4. **Customize Prompts** - Adapt AI prompts for your brand
5. **Integrate Social Media** - Set up social posting automation
6. **Monitor Performance** - Track content and affiliate performance

## 🆘 Need Help?

- Check the `docs/` directory for detailed documentation
- Review the `reference/` directory for working examples
- Study the configuration files in `config/`
- Test with the provided sample content
