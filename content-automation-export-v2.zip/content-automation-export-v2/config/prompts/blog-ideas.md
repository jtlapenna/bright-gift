# Blog Ideas Prompt

See reference files for prompt examples.