# Blog Content Prompt

See reference files for prompt examples.